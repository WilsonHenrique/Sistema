<?php
require_once '../App/auth.php';
echo $usuario;
	echo '<br/>';
	echo $perm;
?>